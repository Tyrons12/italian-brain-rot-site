import React from "react";
import { Button } from "@/components/ui/button";

export default function ItalianBrainRot() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-green-600 via-white to-red-600 text-black font-sans">
      {/* Hero Section */}
      <section className="text-center py-20">
        <div className="text-6xl font-bold flex justify-center items-center gap-4">
          <img
            src="/logo.png"
            alt="$IBR Logo"
            className="w-24 h-24 animate-spin-slow"
          />
          $IBR
        </div>
        <p className="mt-4 text-2xl">Too Much Espresso. Zero Utility. Pure Chaos. 🇮🇹</p>
        <Button className="mt-6 text-lg bg-yellow-400 hover:bg-yellow-500">BUY NOW</Button>
        <div className="mt-6 text-sm italic">Hold or become a meatball 🍝</div>
      </section>

      {/* About Section */}
      <section className="bg-red-600 text-white py-12 px-4 text-center">
        <h2 className="text-3xl font-bold mb-4">ABOUT</h2>
        <p className="max-w-3xl mx-auto">
          Born from a diet of pasta, memes, and irrational b̶e̶h̶a̶v̶i̶o̶r, Italian Brain Rot ($IBR) is the coinchan token we all need right now.
        </p>
        <div className="flex justify-center gap-6 mt-8">
          <img src="/memes/pasta.jpg" alt="Only Pasta" className="w-40 h-40 rounded-xl" />
          <img src="/memes/italian.jpg" alt="Italian Behavior" className="w-40 h-40 rounded-xl" />
          <img src="/memes/goodjob.jpg" alt="Good Job" className="w-40 h-40 rounded-xl" />
        </div>
      </section>

      {/* Tokenomics Section */}
      <section className="bg-white py-12 px-4 text-center">
        <h2 className="text-3xl font-bold mb-4 text-green-700">TOKENOMICS</h2>
        <ul className="text-lg">
          <li>✅ Supply: 1,000,000,000</li>
          <li>✅ 0% taxes – because we're not that kind of pasta</li>
        </ul>
        <div className="mt-6">
          <img src="/memes/mario.jpg" alt="Mario Tokenomics" className="w-48 mx-auto rounded-xl" />
        </div>
      </section>

      {/* How to Buy Section */}
      <section className="bg-orange-500 text-white py-12 px-4 text-center">
        <h2 className="text-3xl font-bold mb-4">HOW TO BUY</h2>
        <ol className="text-lg space-y-2">
          <li>1️⃣ Install Phantom Wallet</li>
          <li>2️⃣ Buy on <span className="font-bold">pump.fun</span></li>
        </ol>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-6 text-center space-y-2">
        <p>© 2025 Italian Brain Rot ($IBR). No Rights Reserved.</p>
        <a
          href="https://t.me/+7Zer7ooajMM3YWFk"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-full transition"
        >
          💬 Join Our Telegram
        </a>
      </footer>
    </main>
  );
}
